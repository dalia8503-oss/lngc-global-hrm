# =============================================
#  호선별 담당정보 입력 폼 - 설정 커스터마이징
#  이 파일과 hoseon_input.html을 같은 폴더에 두고 실행하세요
# =============================================

# ✅ 여기만 수정하세요 -----------------------

# 앱 제목 / 부제목
TITLE    = "호선별 담당정보 입력"
SUBTITLE = "직종 선택 후 TK별 담당자를 입력하세요"

# 직종 목록 (개수 자유롭게 추가/삭제 가능)
JOBS = [
    'A직종',
    'B직종',
    'C직종',
    'D직종',
    'E직종',
    'F직종',
    'G직종',
    'H직종',
    'I직종',
]

# TK 목록 (4→3→2→1 순서로 입력)
TKS = ['4TK', '3TK', '2TK', '1TK']

# 담당자 최대 입력 수 (1~5 사이 권장)
MAX_PERSONS = 3

# 출력 파일 이름
OUTPUT_FILE = "hoseon_input_custom.html"

# --------------------------------------------


import re, os

INPUT_FILE = "hoseon_input.html"

def build_job_tabs(jobs):
    return "\n".join(
        f'    <button class="job-tab" onclick="selectJob(\'{j}\')">{j}</button>'
        for j in jobs
    )

def build_person_rows(max_persons):
    circles = ['①','②','③','④','⑤']
    rows = []
    for i in range(max_persons):
        label = "담당자 1" if i == 0 else f"담당자 {i+1} (선택)"
        rows.append(
            f'        <div class="name-row">'
            f'<span>{circles[i]}</span>'
            f'<input type="text" data-tk="${{tk}}" data-idx="{i}" placeholder="{label}" value="${{escHtml(vals[{i}])}}"></div>'
        )
    return "\n".join(rows)

def main():
    if not os.path.exists(INPUT_FILE):
        print(f"❌ '{INPUT_FILE}' 파일을 찾을 수 없어요.")
        print(f"   이 스크립트와 같은 폴더에 '{INPUT_FILE}'을 넣어주세요.")
        return

    with open(INPUT_FILE, encoding="utf-8") as f:
        html = f.read()

    # 1) 제목 / 부제목
    html = re.sub(
        r'(<h1>).*?(</h1>)',
        rf'\g<1>{TITLE}\g<2>',
        html
    )
    html = re.sub(
        r'(<title>).*?(</title>)',
        rf'\g<1>{TITLE}\g<2>',
        html
    )
    html = re.sub(
        r'(<p>)(직종 선택 후.*?)(</p>)',
        rf'\g<1>{SUBTITLE}\g<3>',
        html
    )

    # 2) 직종 탭 버튼 교체
    tab_html = build_job_tabs(JOBS)
    html = re.sub(
        r'(<div class="job-tabs" id="jobTabs">).*?(</div>)',
        rf'\1\n{tab_html}\n  \2',
        html,
        flags=re.DOTALL
    )

    # 3) JS: jobs 배열
    jobs_js = ", ".join(f"'{j}'" for j in JOBS)
    html = re.sub(
        r"const jobs = \[.*?\];",
        f"const jobs = [{jobs_js}];",
        html
    )

    # 4) JS: tks 배열
    tks_js = ", ".join(f"'{t}'" for t in TKS)
    html = re.sub(
        r"const tks = \[.*?\];",
        f"const tks = [{tks_js}];",
        html
    )

    # 5) 담당자 수: data 초기화 배열 크기
    empty = ", ".join(["''"] * MAX_PERSONS)
    html = re.sub(
        r"data\[j\]\[tk\] = \[.*?\];",
        f"data[j][tk] = [{empty}];",
        html
    )

    # 6) 담당자 입력 rows (renderTKs 함수 내부 name-inputs 블록)
    person_rows = build_person_rows(MAX_PERSONS)
    html = re.sub(
        r'(<div class="name-inputs">).*?(</div>\s*</div>\s*`;)',
        rf'\1\n{person_rows}\n      \2',
        html,
        flags=re.DOTALL
    )

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"✅ '{OUTPUT_FILE}' 생성 완료!")
    print(f"   직종: {JOBS}")
    print(f"   TK  : {TKS}")
    print(f"   담당자 최대 {MAX_PERSONS}명")

if __name__ == "__main__":
    main()
